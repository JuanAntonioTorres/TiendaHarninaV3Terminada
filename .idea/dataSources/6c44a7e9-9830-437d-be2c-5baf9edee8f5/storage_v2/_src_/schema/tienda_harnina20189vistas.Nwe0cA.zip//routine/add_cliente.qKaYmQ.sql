create procedure add_cliente(IN  NifCliente_in       varchar(9), IN ApellidosCliente_in varchar(100),
                             IN  NombreCliente_in    varchar(50), IN CodigoPostalCliente_in varchar(5),
                             IN  DomicilioCliente_in varchar(100), IN FechaNacimiento_in date,
                             IN  TelefonoCliente_in  varchar(20), IN MovilCliente_in varchar(20),
                             IN  SexoCliente_in      char, IN EmailCliente_in varchar(150),
                             IN  ImagenCliente_in    varchar(15), IN UsuarioCliente_in varchar(30),
                             IN  PasswordCliente_in  varchar(50), OUT mensa tinyint(1))
  BEGIN

INSERT INTO tienda_harnina20189.`cliente`( `NifCliente`, `ApellidosCliente`, `NombreCliente`, `CodigoPostalCliente`, `DomicilioCliente`, `FechaNacimiento`, `TelefonoCliente`, `MovilCliente`, `SexoCliente`, `EmailCliente`, `ImagenCliente`, `UsuarioCliente`, `PasswordCliente`, `fechaAlta`) VALUES (NifCliente_in,ApellidosCliente_in,NombreCliente_in,CodigoPostalCliente_in,DomicilioCliente_in,FechaNacimiento_in,TelefonoCliente_in,MovilCliente_in,SexoCliente_in,EmailCliente_in,ImagenCliente_in,UsuarioCliente_in,md5(PasswordCliente_in),CURRENT_TIMESTAMP);

IF ROW_COUNT() > 0 THEN SET mensa = true;
   ELSE SET mensa =  false;
END IF;

END;

