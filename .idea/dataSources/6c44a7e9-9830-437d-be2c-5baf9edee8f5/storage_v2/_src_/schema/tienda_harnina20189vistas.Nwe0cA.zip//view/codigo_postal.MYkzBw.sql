create view codigo_postal as
  select distinct `tienda_harnina20189`.`codigopostal`.`CodigoPostal` AS `CodigoPostal`
  from `tienda_harnina20189`.`codigopostal`
  where 1
  order by 1;

