create procedure get_nif_login(IN usuario_in varchar(30), IN password_in varchar(50), OUT mensa varchar(9))
  BEGIN

Set mensa = "null";

 SELECT `dni` into mensa FROM `login_cliente` WHERE `usuario` = usuario_in and `password` = md5(password_in);
 

 
END;

