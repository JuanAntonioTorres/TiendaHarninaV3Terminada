create view login_cliente as
  select `tienda_harnina20189`.`cliente`.`NifCliente`      AS `dni`,
         `tienda_harnina20189`.`cliente`.`UsuarioCliente`  AS `usuario`,
         `tienda_harnina20189`.`cliente`.`PasswordCliente` AS `password`
  from `tienda_harnina20189`.`cliente`
  where 1;

