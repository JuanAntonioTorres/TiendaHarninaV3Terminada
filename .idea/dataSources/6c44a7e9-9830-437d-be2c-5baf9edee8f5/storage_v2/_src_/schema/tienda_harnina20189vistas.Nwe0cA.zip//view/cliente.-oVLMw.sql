create view cliente as
  select `tienda_harnina20189`.`cliente`.`NifCliente`          AS `NifCliente`,
         `tienda_harnina20189`.`cliente`.`ApellidosCliente`    AS `ApellidosCliente`,
         `tienda_harnina20189`.`cliente`.`NombreCliente`       AS `NombreCliente`,
         `tienda_harnina20189`.`cliente`.`CodigoPostalCliente` AS `CodigoPostalCliente`,
         `tienda_harnina20189`.`cliente`.`DomicilioCliente`    AS `DomicilioCliente`,
         `tienda_harnina20189`.`cliente`.`FechaNacimiento`     AS `FechaNacimiento`,
         `tienda_harnina20189`.`cliente`.`TelefonoCliente`     AS `TelefonoCliente`,
         `tienda_harnina20189`.`cliente`.`MovilCliente`        AS `MovilCliente`,
         `tienda_harnina20189`.`cliente`.`SexoCliente`         AS `SexoCliente`,
         `tienda_harnina20189`.`cliente`.`EmailCliente`        AS `EmailCliente`,
         `tienda_harnina20189`.`cliente`.`ImagenCliente`       AS `ImagenCliente`
  from `tienda_harnina20189`.`cliente`
  where 1;

